-- AlterTable
ALTER TABLE "Discussion" ADD COLUMN     "voters" TEXT[];
