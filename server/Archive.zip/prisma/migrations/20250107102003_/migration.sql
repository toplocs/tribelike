-- AlterTable
ALTER TABLE "Location" ADD COLUMN     "geom" BYTEA;
