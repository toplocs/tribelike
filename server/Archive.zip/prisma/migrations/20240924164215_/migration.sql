-- AlterTable
ALTER TABLE "Profile" ADD COLUMN     "about" TEXT;
