-- AlterTable
ALTER TABLE "Location" ADD COLUMN     "zoom" TEXT;
