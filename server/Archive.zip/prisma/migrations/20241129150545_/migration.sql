/*
  Warnings:

  - You are about to drop the column `dataId` on the `Relation` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Relation" DROP COLUMN "dataId";
