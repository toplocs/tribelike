-- AlterTable
ALTER TABLE "Invite" ALTER COLUMN "profileId" DROP NOT NULL;
