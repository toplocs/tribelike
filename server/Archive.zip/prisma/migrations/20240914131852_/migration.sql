-- AlterTable
ALTER TABLE "Location" ADD COLUMN     "xCoordinate" TEXT,
ADD COLUMN     "yCoordinate" TEXT;
