-- AlterTable
ALTER TABLE "Interest" ADD COLUMN     "ask" TEXT[];
