-- DropIndex
DROP INDEX "Profile_username_key";
