-- AlterTable
ALTER TABLE "Discussion" ADD COLUMN     "limit" INTEGER NOT NULL DEFAULT 1;
