-- AlterTable
ALTER TABLE "User" ADD COLUMN     "image" TEXT;
