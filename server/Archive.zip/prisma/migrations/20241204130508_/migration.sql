-- AlterTable
ALTER TABLE "Discussion" ALTER COLUMN "limit" DROP DEFAULT;
