import{i as r}from"./pako.esm-CPws4d4z.js";import{B as a}from"./basedecoder-DvumDe3Y.js";class s extends a{decodeBlock(e){return r(new Uint8Array(e)).buffer}}export{s as default};
