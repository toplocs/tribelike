export = [
  {
    "type": "Family",
    "image": "/images/default.jpeg",
    "about": "This profile is for family members."
  },
  {
    "type": "Friends",
    "image": "/images/default.jpeg",
    "about": "This is a profile for close friends."
  },
  {
    "type": "Work",
    "image": "/images/default.jpeg",
    "about": "This profile is for professional contacts."
  }
];
