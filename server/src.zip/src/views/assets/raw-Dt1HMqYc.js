import{B as o}from"./basedecoder-DvumDe3Y.js";class d extends o{decodeBlock(e){return e}}export{d as default};
